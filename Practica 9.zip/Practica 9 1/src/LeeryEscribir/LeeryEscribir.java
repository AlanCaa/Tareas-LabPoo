/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LeeryEscribir;
import java.util.Scanner;
public class LeeryEscribir {
    Scanner scntec = new Scanner(System.in);
    public String leer;
    public String escribir;

    public LeeryEscribir(String leer, String escribir) {
        this.leer = leer;
        this.escribir = escribir;
    }

    public LeeryEscribir() {
    }

    public String imprimir() {
        //System.out.println(this.leer);
        return "Con este codigo se probara como escribir y leer archivos";
    }
    public String teclar(){
        System.out.println("Ingrese una cadena de texto: ");
        escribir = scntec.nextLine();
        return "";
    }
    
}
