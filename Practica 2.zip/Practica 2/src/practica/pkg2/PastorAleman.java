/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class PastorAleman extends Perro{
 
    public void cariñoso(){
        System.out.println("El pastor aleman es muy cariñoso ");
    }
    public void jugar(){
        System.out.println("El pastor aleman juega mucho");
    }
}
