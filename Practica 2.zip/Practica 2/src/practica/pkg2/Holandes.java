/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Holandes extends Conejo{
    
    public void calmado(){
            System.out.println("El conejo Holandes es muy calmado");
}
    public void trucos (){
            System.out.println("El conejo Holandes puede aprender trucos con facilidad");
    }
    
    public void cariños(){
            System.out.println("El conejo Holandes es muy cariñoso con su dueño ");
    }
    
}
