/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class HollandLop extends Conejo{
    
    public void gordo(){
        System.out.println("El conejo holland lop es ancho");
    }
    
    public void sacudir(){
        System.out.println("Al conejo holland lop le gusta sacudir mucho las orejas");
    }
    
}
