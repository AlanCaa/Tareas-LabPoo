/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Chihuahua extends Perro {
    
    public void muerde(){
        System.out.println("El chihuahua muerde mucho");
    }
    public void enojo(){
        System.out.println("El chihuahua se enoja mucho");
    }
    
}
