/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Perico extends Ave{
    
    public void hablar(){
        System.out.println("Los pericos hablan mucho");
    }
    public void pico(){
        System.out.println("Los pericos tienen pico grande");
    }
    public void color(){
        System.out.println("Las plumas de los pericos suelen ser de colores vivos");
    }
    
}
