/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Perro extends Animal{
    
    public void ladrar(){
        System.out.println("El perro ladra");
    }
    public void corre(){
        System.out.println("El perro corre mucho");
    }
    public void moverCola(){
        System.out.println("Perro moviendo la cola");
    }
}
