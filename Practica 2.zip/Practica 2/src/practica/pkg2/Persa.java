/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Persa extends Gato {
    
    public void ronronear(){
        System.out.println("El gato persa ronronea mucho");
    }
    public void juego(){
        System.out.println("El gato persa es jugueton");
    }
}
