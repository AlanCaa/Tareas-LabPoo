/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Siames extends Gato{
    
    public void dormir(){
        System.out.println("El gato siames duerme mucho");
    }
    public void cariño(){
        System.out.println("El gato siames es muy cariñoso");
    }
}
