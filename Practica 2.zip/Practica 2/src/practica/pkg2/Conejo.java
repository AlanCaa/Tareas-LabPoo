/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Conejo extends Animal {
    
    public void salta(){
        System.out.println("Los conejos saltan mucho");    
}
    
}
