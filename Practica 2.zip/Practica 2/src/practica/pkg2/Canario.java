/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg2;

/**
 *
 * @author ajosu
 */
public class Canario extends Ave{
    
    public void cantar(){
        System.out.println("Los canarios canta mucho");
    }
    public void pluma(){
        System.out.println("El color de las plumas de los canarios suele ser amarillento");
    }
    public void peque(){
        System.out.println("Los cabaruis suelen ser pequeños");
    }
    
}
